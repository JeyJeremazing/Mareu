package com.example.mareu.controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.mareu.R;

public class MeetingDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meeting_details);
    }
}